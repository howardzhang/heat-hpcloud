#!/bin/bash
echo "WARNING: This script now make no modifications to the current flavors"
nova flavor-list
